var searchData=
[
  ['totspec',['totSpec',['../structsimValues.html#aeb4d9fe040a0ecb69669675753088a10',1,'simValues']]]
];
