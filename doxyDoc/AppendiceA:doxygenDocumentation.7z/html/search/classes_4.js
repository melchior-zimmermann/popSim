var searchData=
[
  ['nextgen',['NextGen',['../classNextGen.html',1,'']]],
  ['noevo',['NoEvo',['../classNoEvo.html',1,'']]]
];
