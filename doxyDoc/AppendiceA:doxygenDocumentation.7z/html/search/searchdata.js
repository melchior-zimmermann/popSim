var indexSectionsWithContent =
{
  0: "abcdefghilmnoprst",
  1: "ceimns",
  2: "cehimnrs",
  3: "cgilmrs",
  4: "abcdefgimnoprst",
  5: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

